if (isMobileScreen()) {
    document.querySelector('#menu-list').classList.add('hidden');
}