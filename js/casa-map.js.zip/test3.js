$('document').ready(function(){
    alert('no dot here');
});