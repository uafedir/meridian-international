function isMobileScreen() {
    const w = window, d = document, e = d.documentElement, g = d.getElementsByTagName('body')[0],
        viewportWidth = w.innerWidth || e.clientWidth || g.clientWidth;
    const breakpoint = 768;
    return viewportWidth < breakpoint;
}