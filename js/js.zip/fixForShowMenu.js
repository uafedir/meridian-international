"use strict";

if (isMobileScreen()) {
  document.querySelector("#menu-list").classList.add("menu-hidden");
} else {
  document.querySelector("#menu-list").classList.remove("menu-hidden");
}
